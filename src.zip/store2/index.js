import { createStore } from 'react-redux';


const initState = {
    teachers: [],
    students: [],
    selectedTeacher: {},
    groupStudents: []
};

const reducer = (state = initState, action) => {
    switch (action.type) {
        case "SET_TEACHERS": {
            return {
                ...state,
                teachers: action.teachers
            }
        }

        case "SET_STUDENTS": {
            return {
                ...state,
                students: action.students
            }
        }

        case "SET_SELECTED_TEACHER": {
            const filteredStudents = state.students.filter(st => st.group === action.teacher.group);
            return {
                ...state,
                selectedTeacher: action.teacher,
                groupStudents: filteredStudents
            }
        }
    
        default:
            return state;
    }
}



const appStore = createStore(reducer);

export default appStore;