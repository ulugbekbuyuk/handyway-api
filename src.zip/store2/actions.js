
export const setTeachers = (teachers) => {
    return {
        type: "SET_TEACHERS",
        teachers
    }
}

export const setStudents = (students) => {
    return {
        type: "SET_STUDENTS",
        students
    }
}

export const setSelectedTeacher = (teacher) => {
    return {
        type: "SET_SELECTED_TEACHER",
        teacher
    }
}