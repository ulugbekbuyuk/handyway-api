import actionTypes from "./actionTypes";

const initAuthState = {
    isAuthorized: false,
    token: '',
    user: '',
    role: '',
    isLoading: false,
    error: {}
};

const authReducer = (state = initAuthState, action) => {
    switch (action.type) {
        case actionTypes.SET_AUTH: {

            return state;
        }

        case actionTypes.SET_ERROR: {
            return { 
                ...initAuthState,
                error: action.payload.error
            }
        }

        case actionTypes.SET_LOADING: {
            return { 
                ...state,
                isLoading: action.payload.isLoading
            }
        }
    
        default:
            return state;
    }
}

export default authReducer;