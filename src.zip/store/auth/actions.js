import actionTypes from "./actionTypes";

export const setAuth = (params) => {
    return {
        type: actionTypes.SET_AUTH,
        payload: {
            params
        }
    };
}

export const setError = (error) => {
    return {
        type: actionTypes.SET_ERROR,
        payload: {
            error
        }
    };
}

export const setLoading = (isLoading) => {
    return {
        type: actionTypes.SET_LOADING,
        payload: {
            isLoading
        }
    };
}


export const loginUser = (url, params) => {
    return async (dispatch) => {
        dispatch(setLoading(true));
        try {
            const httpResponse = await axios.post(url, params);
            if(httpResponse.status === 200) {
                return dispatch(setAuth(httpResponse.data));
            } else {
                return dispatch(setAuth(null));
            }
        } catch (error) {
            return dispatch(setError(error));
        }
    }
}