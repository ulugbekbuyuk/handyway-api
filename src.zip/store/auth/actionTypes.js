const actionTypes = {
    SET_AUTH: "SET_AUTH",
    SET_ERROR: "SET_ERROR",
    SET_LOADING: "SET_LOADING"
};

export default actionTypes;