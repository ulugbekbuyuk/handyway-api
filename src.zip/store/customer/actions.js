import actionTypes from "./actionTypes";
import axios from 'axios';

export const setCustomers = (customers) => {
    return {
        type: actionTypes.SET_CUSTOMERS,
        payload: {
            customers
        }
    };
}

export const addCustomer = () => {
    return {
        type: actionTypes.ADD_CUSTOMER,
        payload: {}
    };
}

export const updateCustomer = () => {
    return {
        type: actionTypes.UPDATE_CUSTOMER,
        payload: {}
    };
}

export const deleteCustomer = () => {
    return {
        type: actionTypes.DELETE_CUSTOMER,
        payload: {}
    };
}

export const onError = (error) => {
    return {
        type: actionTypes.ON_ERROR,
        payload: {
            error
        }
    };
}

export const setLoading = (isLoading) => {
    return {
        type: actionTypes.ON_LOADING,
        payload: {
            isLoading
        }
    };
}

// https://github.com/aesthytik/redux-thunk-example
// Here is an example
export const fetchingCustomers = (url) => {
    return async (dispatch) => {
        dispatch(setLoading(true));
        try {
            const httpResponse = await axios.get(url);
            if(httpResponse.status === 200) {
                return dispatch(setCustomers(httpResponse.data));
            } else {
                return dispatch(setCustomers([]));
            }
        } catch (error) {
            return dispatch(onError(error));
        }
    }
}


// Example of how to use thunks


// ...

// useEffect() {
//     fetchData('some-url');
// }

// ...
// const mapStateToProps = (state) => {
//     return {
//         items: state.items,
//         hasError: state.itemsHaveError,
//         isLoading: state.itemsAreLoading
//     };
// };

// const mapDispatchToProps = (dispatch) => {
//     return {
//         fetchData: (url) => dispatch(fetchingCustomers(url))
//     };
// };

// export default connect(mapStateToProps, mapDispatchToProps)(ItemList);