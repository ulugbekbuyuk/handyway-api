import actionTypes from "./actionTypes";

const initState = {
    customers: [],
    isLoading: false,
    error: {}
};

const customerReducer = (state = initState, action) => {
    switch (action.type) {
        case actionTypes.SET_CUSTOMERS: {
            return {
                ...initState,
                customers: action.payload.customers
            };
        }

        case actionTypes.ADD_CUSTOMER: {
            return state;
        }

        case actionTypes.ON_ERROR: {
            return { 
                ...state, 
                error: action.payload.error,
                isLoading: false
            };
        }

        case actionTypes.ON_LOADING: {
            return { 
                ...state, 
                isLoading: action.payload.isLoading,
                error: {}
            };
        }
    
        default:
            return state;
    }
}

export default customerReducer;