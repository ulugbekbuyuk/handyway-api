import React from 'react';
import { connect } from 'react-redux';
import { setSelectedTeacher } from './../../store2/actions';

const TeacherList = (props) => {
    const { teacherList, setStoreTeacher } = props;

    const selectTeacher = (teacher) => {
        setStoreTeacher(teacher);
    }

    return (
        <div>
            {teacherList.map(teacher => <li onClick={selectTeacher(teacher)}>{teacher.name}</li>)}
        </div>
    );
}


const mapStateToProps = (state) => {
    return {
        teacherList: state.teachers
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        setStoreTeacher: (teacher) => dispatch(setSelectedTeacher(teacher))
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TeacherList)