import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedTeacher, setTeachers } from '../../store2/actions';

const TeacherList = () => {
    
    const dispatch = useDispatch();
    const teacherList = useSelector(state => state.teachers);
    const studentList = useSelector(state => state.students);

    const selectTeacher = (teacher) => {
        dispatch(setSelectedTeacher(teacher));
    }

    useEffect(() => {
        // 
        axios.get('url').then(data => {
            // dispatch({
            //     type: "SET_TEACHERS",
            //     teachers: data
            // })
            dispatch(setTeachers(data));
        });
    })

    return (
        <div>
            {teacherList.map(teacher => <li onClick={selectTeacher(teacher)}>{teacher.name}</li>)}
        </div>
    );
}



export default TeacherList;